# 🚀 PyAutomate AI – Advanced

An enterprise‑grade, AI‑powered automation platform featuring:

* ✅ RPA + Selenium headless automation
* ✅ Background task processing (Celery + RabbitMQ)
* ✅ OCR & document classification
* ✅ YAML‑driven workflow designer
* ✅ JWT/OAuth2 authentication
* ✅ Streamlit dashboard
* ✅ Dockerized dev and prod setups
* ✅ GitHub Actions CI

## Quick Start (Local Dev)

```bash
git clone https://github.com/yourusername/pyautomate-ai.git
cd PyAutomateAI_Advanced
cp .env.example .env         # customise secrets
docker-compose up --build    # starts Postgres, RabbitMQ, backend, Celery
```

Frontend:

```bash
cd frontend
pip install -r ../backend/requirements.txt     # reuse deps
streamlit run dashboard.py
```

See `docs/` for architecture diagrams & API reference.
