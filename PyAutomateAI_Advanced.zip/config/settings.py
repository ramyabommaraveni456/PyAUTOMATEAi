from pydantic import BaseSettings

class Settings(BaseSettings):
    app_name: str = "PyAutomate AI – Advanced"
    database_url: str = "postgresql://postgres:postgres@db:5432/pyautomate"
    secret_key: str = "CHANGE_ME_SECRET_KEY"
    class Config:
        env_file = ".env"

settings = Settings()
