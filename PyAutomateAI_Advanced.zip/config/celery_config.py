from celery.schedules import crontab
from app.tasks.celery_app import celery_app

celery_app.conf.beat_schedule = {
    'nightly-workflow': {
        'task': 'app.tasks.tasks.run_async_rpa',
        'schedule': crontab(hour=2, minute=0),
        'args': ('https://example.com',),
    },
}
