import streamlit as st, yaml, requests, pandas as pd

st.set_page_config(page_title="PyAutomate AI – Advanced", layout="wide")
st.title("🚀 PyAutomate AI – Advanced Dashboard")

api_base = st.text_input("Backend API base URL", "http://localhost:8000")

# Authentication
st.sidebar.header("Login")
username = st.sidebar.text_input("Username")
password = st.sidebar.text_input("Password", type="password")
if st.sidebar.button("Login"):
    resp = requests.post(f"{api_base}/api/auth/login", data={"username": username, "password": password})
    if resp.ok:
        token = resp.json()["access_token"]
        st.session_state["token"] = token
        st.sidebar.success("Logged in!")
    else:
        st.sidebar.error("Login failed")

token = st.session_state.get("token")
headers = {"Authorization": f"Bearer {token}"} if token else {}

st.header("Run RPA Task")
url = st.text_input("URL to automate")
if st.button("Queue RPA Job") and token:
    r = requests.post(f"{api_base}/api/automation/run", json={"url": url}, headers=headers)
    st.write(r.json())

st.header("OCR & Classification")
uploaded_file = st.file_uploader("Upload image or PDF", type=["png", "jpg", "jpeg", "pdf"])
if st.button("Extract Text") and uploaded_file and token:
    files = {"file": (uploaded_file.name, uploaded_file.getvalue())}
    r = requests.post(f"{api_base}/api/ocr/extract", files=files, headers=headers)
    st.json(r.json())

st.header("Workflow Designer (YAML)")
default_yaml = """steps:
  - action: rpa
    url: https://example.com
  - action: shell
    script: echo 'Workflow step completed'
"""
yaml_text = st.text_area("Workflow YAML", default_yaml, height=300)
if st.button("Execute Workflow") and token:
    r = requests.post(f"{api_base}/api/workflow/execute", json={"yaml_config": yaml_text}, headers=headers)
    st.json(r.json())
