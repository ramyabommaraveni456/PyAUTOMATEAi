import requests
from bs4 import BeautifulSoup
def simple_scrape(url: str):
    resp = requests.get(url, timeout=10)
    soup = BeautifulSoup(resp.text, 'html.parser')
    return soup.title.string if soup.title else "No title"
