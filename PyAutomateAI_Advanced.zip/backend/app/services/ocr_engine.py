import pytesseract, io, spacy
from PIL import Image
from pdf2image import convert_from_bytes
nlp = spacy.load("en_core_web_sm")

def _image_bytes_to_image(data: bytes):
    return Image.open(io.BytesIO(data))

def extract_text_and_classify(data: bytes):
    # Detect if PDF
    try:
        images = convert_from_bytes(data)
        text = " ".join([pytesseract.image_to_string(img) for img in images])
    except Exception:
        img = _image_bytes_to_image(data)
        text = pytesseract.image_to_string(img)

    doc = nlp(text)
    label = "invoice" if any(tok.like_num and tok.text.lower().startswith("total") for tok in doc) else "generic"
    return text, label
