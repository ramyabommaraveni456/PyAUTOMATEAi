import yaml, subprocess, tempfile, os
from app.services import rpa_engine

def execute_step(step):
    action = step.get("action")
    if action == "rpa":
        return rpa_engine.run_web_automation(step["url"])
    if action == "shell":
        with tempfile.NamedTemporaryFile(delete=False, mode="w") as f:
            f.write(step["script"])
        subprocess.run(["bash", f.name], check=True)
        os.unlink(f.name)
        return "shell_executed"
    raise ValueError(f"Unknown action {action}")

def execute_workflow_yaml(yaml_config: str):
    workflow = yaml.safe_load(yaml_config)
    results = []
    for step in workflow.get("steps", []):
        results.append(execute_step(step))
    return results
