import joblib
from pathlib import Path
from sklearn.linear_model import LogisticRegression

MODEL_PATH = Path(__file__).resolve().parent.parent.parent / "ml_models" / "classifier.pkl"
if MODEL_PATH.exists():
    model = joblib.load(MODEL_PATH)
else:
    model = LogisticRegression()
    model.classes_ = ["negative", "positive"]
    model.coef_ = [[0]]
    model.intercept_ = [0]

def predict_label(text: str):
    return model.predict([text])[0]
