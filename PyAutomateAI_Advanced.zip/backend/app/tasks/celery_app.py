from celery import Celery

celery_app = Celery(
    "pyautomate_tasks",
    broker="pyamqp://guest@rabbitmq//",
    backend="rpc://"
)
