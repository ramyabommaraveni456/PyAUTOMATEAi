from .celery_app import celery_app
from app.services import rpa_engine

@celery_app.task
def run_async_rpa(url: str):
    title = rpa_engine.run_web_automation(url)
    return {"url": url, "title": title}
