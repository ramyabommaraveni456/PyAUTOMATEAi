from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.workflow_engine import execute_workflow_yaml

router = APIRouter()

class WorkflowRequest(BaseModel):
    yaml_config: str

@router.post("/execute")
async def execute(workflow_req: WorkflowRequest):
    try:
        result = execute_workflow_yaml(workflow_req.yaml_config)
        return {"status": "completed", "result": result}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
