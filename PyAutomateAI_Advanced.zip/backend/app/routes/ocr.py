from fastapi import APIRouter, UploadFile, File, HTTPException
from app.services.ocr_engine import extract_text_and_classify

router = APIRouter()

@router.post("/extract")
async def ocr_extract(file: UploadFile = File(...)):
    if not file.filename.lower().endswith((".png", ".jpg", ".jpeg", ".pdf")):
        raise HTTPException(status_code=400, detail="Unsupported file type")
    text, label = extract_text_and_classify(await file.read())
    return {"text": text, "label": label}
