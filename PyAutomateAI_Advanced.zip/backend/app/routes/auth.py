from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from app.utils.auth import authenticate_user, create_access_token, get_password_hash
from app.db import crud, models, database

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")

@router.post("/signup")
async def signup(username: str, password: str):
    db = database.SessionLocal()
    if crud.get_user_by_username(db, username):
        raise HTTPException(status_code=400, detail="Username already registered")
    user = crud.create_user(db, username=username, password_hash=get_password_hash(password))
    return {"id": user.id, "username": user.username}

@router.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    db = database.SessionLocal()
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = create_access_token({"sub": user.username})
    return {"access_token": token, "token_type": "bearer"}
