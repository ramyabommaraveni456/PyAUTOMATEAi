from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from app.services import rpa_engine
from app.tasks.tasks import run_async_rpa

router = APIRouter()

class RPARequest(BaseModel):
    url: str

@router.post("/run")
async def run_rpa(req: RPARequest, background_tasks: BackgroundTasks):
    background_tasks.add_task(run_async_rpa, req.url)
    return {"status": "queued", "url": req.url}
