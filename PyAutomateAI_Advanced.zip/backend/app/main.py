from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from app.routes import automation, auth, ocr, workflow
from app.utils.auth import get_current_user
from app.tasks.celery_app import celery_app  # Ensure Celery app is imported

app = FastAPI(title="PyAutomate AI – Advanced")

# Routers
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(automation.router, prefix="/api/automation", tags=["automation"], dependencies=[Depends(get_current_user)])
app.include_router(ocr.router, prefix="/api/ocr", tags=["ocr"], dependencies=[Depends(get_current_user)])
app.include_router(workflow.router, prefix="/api/workflow", tags=["workflow"], dependencies=[Depends(get_current_user)])

# CORS (adjust origins in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["root"])
async def root():
    return {"status": "running", "message": "Welcome to PyAutomate AI – Advanced backend"}
