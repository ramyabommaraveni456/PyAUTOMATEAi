## Documentation

This folder should contain ER diagrams, architecture docs, sequence diagrams, and user guides.
